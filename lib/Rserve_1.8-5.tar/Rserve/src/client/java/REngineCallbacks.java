package org.rosuda.REngine;

/** REngineCallbacks is a virtual interface that poses as a superclass of all callback delegate classes. */
public interface REngineCallbacks {
}
